import json
import boto3
import os
import base64

def lambda_handler(event, context):
    stepfunctions = boto3.client('stepfunctions')
    
    # Extract the query string parameters
    query_params = event.get('queryStringParameters', {})
    status = query_params.get('status', '').lower()
    encoded_task_token = query_params.get('taskToken')
    decoded_bytes = base64.b64decode(encoded_task_token)
    task_token = decoded_bytes.decode("utf-8")
    # task_token = query_params.get('taskToken')
    
    if status == 'approve':
        output = json.dumps({"Status": "Approved"})
        try:
            stepfunctions.send_task_success(
                taskToken=task_token,
                output=output
            )
            return {
                'statusCode': 200,
                'body': json.dumps('Task approved')                          
            }
        except Exception as e:
            print(e)
            return {
                'statusCode': 500,
                'body': json.dumps('Error processing request')
            }
    elif status == 'decline':
        output = json.dumps({"Status": "Declined"})
        try:
            stepfunctions.send_task_success(
                taskToken=task_token,
                output=output                          
            )
            return {
                'statusCode': 200,
                'body': json.dumps('Task declined')                          
            }
        except Exception as e:
            print(e)
            return {
                'statusCode': 500,
                'body': json.dumps('Error processing request')
            }
    else:
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid status parameter')
        }
